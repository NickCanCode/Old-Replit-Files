
//FUNCTIONS FOR 
function returnText() {
  let userInput = document.getElementById("userInput").value;
  document.getElementById("termsPaste").innerHTML = userInput;
}


//GPT API

const { Configuration, OpenAIApi } = require("openai");

const config = new Configuration({
  apiKey: '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'
});

const openai = new OpenAIApi(config);
userInput = ""
const runPrompt = async () => {
  let prompt = "Please briefly summarize me the following terms and conditions in less than 200 words: " + userInput

  const response = await openai.createCompletion({
    model: "text-davinci-003",
    prompt: prompt,
    temperature: 0.5,
  })

  let answer = response.data.choices[0].text;
  console.log(answer);

}

runPrompt();