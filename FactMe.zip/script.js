//section for doing the actual API call
let fact;
let factData;

async function giveFact() {
  fact = await fetch("https://uselessfacts.jsph.pl/api/v2/facts/random");
  factData = await fact.json();
  console.log(factData);
  //displays the fact
  document.getElementById("randomFact").innerHTML = factData.text;
  //displays the source name
  document.getElementById("source").innerHTML = factData.source;
  //changes the source's link
  document.getElementById("source").href = factData.source_url;
  //changes background color
  colorChange();
}

//changes the background color
let backgroundColor;
let randNum;
function colorChange() {
  //sets a random number to randNum
  randNum = Math.floor(Math.random() * 7);
  console.log(randNum);
  //changes background color based on randNum
  if (randNum == 0) {
    document.body.style.backgroundColor = "#FAFF7F";
  } else if (randNum == 1) {
    document.body.style.backgroundColor = "#91a6ff";
  } else if (randNum == 2) {
    document.body.style.backgroundColor = "#69e279";
  } else if (randNum == 3) {
    document.body.style.backgroundColor = "#c768ff";
  } else if (randNum == 4) {
    document.body.style.backgroundColor = "#ff9933";
  } else if (randNum == 5) {
    document.body.style.backgroundColor = "#f3dfbf";
  } else if (randNum == 6) {
    document.body.style.backgroundColor = "#e56399";
  }
}
