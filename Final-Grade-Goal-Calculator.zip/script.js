//for future https://www.youtube.com/shorts/Eo-4g3jHwsw
let targetGrade;
let currentGrade;
let weight;
let weightDiff;
let currentXweightDiff;
//wanted grade minus current times weight difference
let wantGradeMinusCXWDIFF;
//final
let final;
//for if there is over 100 as final
let over100;
function calculate() {
  targetGrade = document.getElementById("targetGrade").value;
  currentGrade = document.getElementById("currentGrade").value;
  weight = document.getElementById("weight").value / 100;
  weightDiff = 1 - weight;
  currentXweightDiff = currentGrade * weightDiff;
  wantGradeMinusCXWDIFF = targetGrade - currentXweightDiff;
  final = wantGradeMinusCXWDIFF / weight;
  final = Math.round(100 * final) / 100;
  if (final > 100) {
    over100 = final - 100;
    document.getElementById("beforeOutcome").innerHTML = "";
    document.getElementById("outcome").innerHTML = `You need a score greater than 100. Try to contact your professor/teacher to get ${over100}% worth of extra credit in addition to a 100 on your final grade.`;
  }
  else {
    document.getElementById("outcome").innerHTML = `${final}`;
  }
}